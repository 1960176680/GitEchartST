package com.github.abel533.echarts.code;

/**
 * 坐标系
 *
 * @author liuzh
 * @since 2016-02-28 10:20
 */
public enum CoordinateSystem {
    cartesian2d, polar, geo
}
